io_decoder_eval-v1

Move the component file io_decoder.c and the firmware file io_decoder_eval.hex to your preferred location.

Move the io_decoder-keymap.cfg file into your CNC machine's configuration folder if you wish to use the keyboard emulation functionality.

The io_decoder_eval.hex file must be flashed onto the Arduino Uno's memory. Choose the flashing method that best suits your operating system.

For full documentation and setup guides: https://bobwolfrst.github.io/io_decoder-linuxCNC/
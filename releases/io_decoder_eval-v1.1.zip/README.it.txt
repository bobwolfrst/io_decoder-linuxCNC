io_decoder_eval-v1

Sposta il file io_decoder.c del componente ed il file io_decoder_eval.hex dove ti resta più comodo;  

sposta il file io_decoder-keymap.cfg nella cartella della configurazione della macchina cnc, se vuoi usare la funzionalità keyboard.

Il file io_decoder_eval.hex deve essere trasferito sulla memoria dell'Arduino Uno. Scegli il metodo più adatto al tuo sistema operativo.

per tutte le guide complete
https://bobwolfrst.github.io/io_decoder-linuxCNC/